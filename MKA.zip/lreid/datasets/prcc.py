from __future__ import division, print_function, absolute_import
import os
import copy
from lreid.data_loader.incremental_datasets import IncrementalPersonReIDSamples
import re
import glob
import os.path as osp
import warnings

class IncrementalSamples4prcc(IncrementalPersonReIDSamples):
    '''
    PRCC Dataset
    '''
    dataset_name = 'prcc'
    dataset_dir = 'prcc/rgb/'
    dataset_url = 'http://188.138.127.15:81/Datasets/Market-1501-v15.09.15.zip'
    def __init__(self, datasets_root, relabel=True, combineall=False):
        self.relabel = relabel
        self.combineall = combineall
        self.root = osp.join(datasets_root, self.dataset_dir)
        self.train_dir = osp.join(self.root, 'train')
        self.query_dir = osp.join(self.root, 'test')
        self.gallery_dir = osp.join(self.root, 'test')
        # train = self.process_dir(self.train_dir, relabel=True)
        # query = self.process_dir(self.query_dir, relabel=False, is_train=False)
        # gallery = self.process_dir(self.gallery_dir, relabel=False, is_train=False)
        train = self.process_dir(self.train_dir, relabel=True)
        query = self.process_dir(self.query_dir, is_train='C')
        gallery = self.process_dir(self.gallery_dir, is_train='A')
        self.train, self.query, self.gallery = train, query, gallery
        self._show_info(train, query, gallery)

    def process_dir(self, dir_path, relabel=False, is_train=True):
        # img_paths = glob.glob(osp.join(dir_path, '*.png'))
        # pattern = re.compile(r'/(\d+)_(\d+)_c(\d+)')
        # with open(osp.join(self.root, 'info/cloth-change_id_train.txt'), 'r') as f:
        #     h = f.readlines()
        # train_set = [i[:3] for i in h]
        # # train_set_cls = {i: self.cfg.LTCC_NUM * [j for j in range(1, 15)] for i in train_set}
        #
        # with open(osp.join(self.root, 'info/cloth-change_id_test.txt'), 'r') as f:
        #     h = f.readlines()
        # test_set = [i[:3] for i in h]
        #
        # pid_container = set()
        # for img_path in img_paths:
        #     pid, clsid, camid = map(int, pattern.search(img_path).groups())
        #     if is_train:
        #         if '%03d' % (pid) in train_set:
        #             pid_container.add(pid)
        #     else:
        #         # if '%03d' % (pid) in test_set:
        #         pid_container.add(pid)
        # pid2label = {pid: label for label, pid in enumerate(pid_container)}
        #
        # data = []
        # for img_path in img_paths:
        #     pid, clsid, camid = map(int, pattern.search(img_path).groups())
        #     assert 0 <= pid <= 151
        #     assert 1 <= clsid <= 14
        #     assert 1 <= camid <= 12
        #     camid -= 1  # index starts from 0
        #     clsid -= 1
        #     if is_train:
        #         if '%03d' % (pid) in train_set:
        #             if relabel:
        #                 pid = pid2label[pid]
        #             data.append([img_path, pid, camid, 'ltcc', pid])
        #     else:
        #         # if '%03d' % (pid) in test_set:
        #         if relabel:
        #             pid = pid2label[pid]
        #         if self.combineall:
        #             pid = self.dataset_name + "_" + str(pid)
        #             camid = self.dataset_name + "_" + str(camid)
        #         data.append([img_path, pid, camid, 'ltcc', pid])
        # if 'query' in dir_path:
        #     data = data * 7
        # return data

        data = []
        cam_to_int = {'A':0, "B":1, 'C':2}
        # cls_to_int = {'A':0, "B":0, 'C':1}
        pattern = re.compile(r'/[\d]+/(\D)')
        if is_train == True:
            for i in range(92, 333): #[92, 128, 194, 245, 330, ]: #95, 98, 102, 104, 115, 110, 111, 113, 119, 121,122,123,
                # 143,147,149,150,151,154,155, 160,163,164,168,169,170,165,125
                num_identity = '%03d'%(i)
                identity_dir = osp.join(dir_path, num_identity)
                if not osp.exists(identity_dir):
                    continue

                img_paths = glob.glob(osp.join(identity_dir, '*.jpg'))
                pid = i
                for img_path in img_paths:
                    camid = pattern.search(img_path).groups()[0]
                    if camid == 'B':
                        continue
                    camid = cam_to_int[camid]
                    # clsid = self.dataset_name + "_" + str(cls_to_int[camid])
                    data.append([img_path, pid, camid, 'prcc', pid])

            # relabel
            if relabel:
                pid_container = set()
                for img_path, pid, camid, _, _ in data:
                    pid_container.add(pid)
                pid2label = {pid: label for label, pid in enumerate(pid_container)}
                for i, [img_path, pid, camid, _, _] in enumerate(data):
                    data[i][1] = pid2label[pid]
                    data[i][4] = data[i][1]

        elif is_train == 'A':
            dir_path = dir_path + '/' + is_train
            for i in range(1, 329):
                num_identity = '%03d' % (i)
                identity_dir = osp.join(dir_path, num_identity)
                if not osp.exists(identity_dir):
                    continue

                img_paths = glob.glob(osp.join(identity_dir, '*.jpg'))
                # img_path = img_paths[np.random.randint(0, len(img_paths), 1)[0]]
                img_path = img_paths[0]
                if self.combineall:
                    pid = self.dataset_name + "_" + str(i)
                    camid = self.dataset_name + "_" + str(cam_to_int[is_train])
                else:
                    pid = i
                    camid = cam_to_int[is_train]
                data.append([img_path, pid, camid, 'prcc', pid])
        else:
            dir_path = dir_path + '/' + is_train
            for i in range(1, 329):
                num_identity = '%03d' % (i)
                identity_dir = osp.join(dir_path, num_identity)
                if not osp.exists(identity_dir):
                    continue
                if self.combineall:
                    pid = self.dataset_name + "_" + str(i)
                    camid = self.dataset_name + "_" + str(cam_to_int[is_train])
                else:
                    pid = i
                    camid = cam_to_int[is_train]
                img_paths = glob.glob(osp.join(identity_dir, '*.jpg'))
                for img_path in img_paths:
                    data.append([img_path, pid, camid, 'prcc', pid])

        return data