from __future__ import division, print_function, absolute_import
import os
import copy
from lreid.data_loader.incremental_datasets import IncrementalPersonReIDSamples
import re
import glob
import os.path as osp
import warnings

class IncrementalSamples4ltcc(IncrementalPersonReIDSamples):
    '''
    LTCC Dataset
    '''
    dataset_name = 'ltcc'
    dataset_dir = 'LTCC_reID/'
    dataset_url = 'http://188.138.127.15:81/Datasets/Market-1501-v15.09.15.zip'
    def __init__(self, datasets_root, relabel=True, combineall=False):
        self.relabel = relabel
        self.combineall = combineall
        self.root = osp.join(datasets_root, self.dataset_dir)
        self.train_dir = osp.join(self.root, 'train')
        self.query_dir = osp.join(self.root, 'query')
        self.gallery_dir = osp.join(self.root, 'test')
        train = self.process_dir(self.train_dir, relabel=True)
        query = self.process_dir(self.query_dir, relabel=False, is_train=False)
        gallery = self.process_dir(self.gallery_dir, relabel=False, is_train=False)
        self.train, self.query, self.gallery = train, query, gallery
        self._show_info(train, query, gallery)

    def process_dir(self, dir_path, relabel=False, is_train=True):
        img_paths = glob.glob(osp.join(dir_path, '*.png'))
        pattern = re.compile(r'/(\d+)_(\d+)_c(\d+)')
        with open(osp.join(self.root, 'info/cloth-change_id_train.txt'), 'r') as f:
            h = f.readlines()
        train_set = [i[:3] for i in h]
        # train_set_cls = {i: self.cfg.LTCC_NUM * [j for j in range(1, 15)] for i in train_set}

        with open(osp.join(self.root, 'info/cloth-change_id_test.txt'), 'r') as f:
            h = f.readlines()
        test_set = [i[:3] for i in h]

        pid_container = set()
        for img_path in img_paths:
            pid, clsid, camid = map(int, pattern.search(img_path).groups())
            if is_train:
                if '%03d' % (pid) in train_set:
                    pid_container.add(pid)
            else:
                # if '%03d' % (pid) in test_set:
                pid_container.add(pid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}

        data = []
        for img_path in img_paths:
            pid, clsid, camid = map(int, pattern.search(img_path).groups())
            assert 0 <= pid <= 151
            assert 1 <= clsid <= 14
            assert 1 <= camid <= 12
            camid -= 1  # index starts from 0
            clsid -= 1
            if is_train:
                if '%03d' % (pid) in train_set: # 不使用未换衣图片
                    if relabel:
                        pid = pid2label[pid]
                    data.append([img_path, pid, camid, 'ltcc', pid])
            else:
                # if '%03d' % (pid) in test_set:
                if relabel:
                    pid = pid2label[pid]
                if self.combineall:
                    pid = self.dataset_name + "_" + str(pid)
                    camid = self.dataset_name + "_" + str(camid)
                data.append([img_path, pid, camid, 'ltcc', pid])
        if 'query' in dir_path:
            data = data * 7
        return data



class Market1501(IncrementalPersonReIDSamples):
    """Market1501.

    Reference:
        Zheng et al. Scalable Person Re-identification: A Benchmark. ICCV 2015.

    URL: `<http://www.liangzheng.org/Project/project_reid.html>`_

    Dataset statistics:
        - identities: 1501 (+1 for background).
        - images: 12936 (train) + 3368 (query) + 15913 (gallery).
    """
    _junk_pids = [0, -1]
    dataset_dir = 'market1501'
    dataset_url = 'http://188.138.127.15:81/Datasets/Market-1501-v15.09.15.zip'

    def __init__(self, root='', market1501_500k=False, **kwargs):

        self.root = osp.abspath(osp.expanduser(root))
        self.dataset_dir = osp.join(self.root, self.dataset_dir)
        self.download_dataset(self.dataset_dir, self.dataset_url)

        # allow alternative directory structure
        self.data_dir = self.dataset_dir
        data_dir = osp.join(self.data_dir, 'Market-1501-v15.09.15')
        if osp.isdir(data_dir):
            self.data_dir = data_dir
        else:
            warnings.warn(
                'The current data structure is deprecated. Please '
                'put data folders such as "bounding_box_train" under '
                '"Market-1501-v15.09.15".'
            )

        self.train_dir = osp.join(self.data_dir, 'bounding_box_train')
        self.query_dir = osp.join(self.data_dir, 'query')
        self.gallery_dir = osp.join(self.data_dir, 'bounding_box_test')
        self.extra_gallery_dir = osp.join(self.data_dir, 'images')
        # self.market1501_500k = market1501_500k
        #
        # required_files = [
        #     self.data_dir, self.train_dir, self.query_dir, self.gallery_dir
        # ]
        # if self.market1501_500k:
        #     required_files.append(self.extra_gallery_dir)
        # self.check_before_run(required_files)

        train = self.process_dir(self.train_dir, relabel=True)
        query = self.process_dir(self.query_dir, relabel=False)
        gallery = self.process_dir(self.gallery_dir, relabel=False)
        if self.market1501_500k:
            gallery += self.process_dir(self.extra_gallery_dir, relabel=False)

        super(Market1501, self).__init__(train, query, gallery, **kwargs)

    def process_dir(self, dir_path, relabel=False):
        img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([-\d]+)_c(\d)')

        pid_container = set()
        for img_path in img_paths:
            pid, _ = map(int, pattern.search(img_path).groups())
            if pid == -1:
                continue  # junk images are just ignored
            pid_container.add(pid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}

        data = []
        for img_path in img_paths:
            pid, camid = map(int, pattern.search(img_path).groups())
            if pid == -1:
                continue  # junk images are just ignored
            assert 0 <= pid <= 1501  # pid == 0 means background
            assert 1 <= camid <= 6
            camid -= 1  # index starts from 0
            if relabel:
                pid = pid2label[pid]
            data.append((img_path, pid, camid, 'market1501', pid))

        return data
