from __future__ import division, print_function, absolute_import
from lreid.data_loader.incremental_datasets import IncrementalPersonReIDSamples
import os
import re
import glob
import os.path as osp
import warnings

class IncrementalSamples4last(IncrementalPersonReIDSamples):
    '''
    last Dataset
    '''
    dataset_name = 'last'
    dataset_dir = 'last/'
    dataset_url = 'http://188.138.127.15:81/Datasets/Market-1501-v15.09.15.zip'
    def __init__(self, datasets_root, relabel=True, combineall=False):
        self.relabel = relabel
        self.combineall = combineall
        root = osp.join(datasets_root, self.dataset_dir)
        self.train_dir = osp.join(root, 'train')
        self.query_dir = osp.join(root, 'query')
        self.gallery_dir = osp.join(root, 'val')
        train = self.process_dir(self.train_dir, relabel=False)
        # query = self.process_dir(self.query_dir, relabel=False)
        # gallery = self.process_dir(self.gallery_dir, relabel=False)
        self.train, self.query, self.gallery = train, [['*.png', 1, 1, 'last', 1]], [['*.png', 1, 1, 'last', 1]]
        self._show_info(train, [['*.png', 1, 1, 'last', 1]], [['*.png', 1, 1, 'last', 1]])

    def process_dir(self, dir_path, relabel=False):
        data = []
        for i in range(10900):
            num_identity = '%06d'%(i)
            identity_dir = osp.join(dir_path, num_identity)
            if not osp.exists(identity_dir):
                continue

            img_paths = glob.glob(osp.join(identity_dir, '*.jpg'))
            pid = i
            for img_path in img_paths:
                img_name = osp.basename(img_path)
                camid = int(img_name.split('_')[2])
                data.append([img_path, pid, camid, 'ltcc', pid])

        return data[:1024]



class Market1501(IncrementalPersonReIDSamples):
    """Market1501.

    Reference:
        Zheng et al. Scalable Person Re-identification: A Benchmark. ICCV 2015.

    URL: `<http://www.liangzheng.org/Project/project_reid.html>`_

    Dataset statistics:
        - identities: 1501 (+1 for background).
        - images: 12936 (train) + 3368 (query) + 15913 (gallery).
    """
    _junk_pids = [0, -1]
    dataset_dir = 'market1501'
    dataset_url = 'http://188.138.127.15:81/Datasets/Market-1501-v15.09.15.zip'

    def __init__(self, root='', market1501_500k=False, **kwargs):

        self.root = osp.abspath(osp.expanduser(root))
        self.dataset_dir = osp.join(self.root, self.dataset_dir)
        self.download_dataset(self.dataset_dir, self.dataset_url)

        # allow alternative directory structure
        self.data_dir = self.dataset_dir
        data_dir = osp.join(self.data_dir, 'Market-1501-v15.09.15')
        if osp.isdir(data_dir):
            self.data_dir = data_dir
        else:
            warnings.warn(
                'The current data structure is deprecated. Please '
                'put data folders such as "bounding_box_train" under '
                '"Market-1501-v15.09.15".'
            )

        self.train_dir = osp.join(self.data_dir, 'bounding_box_train')
        self.query_dir = osp.join(self.data_dir, 'query')
        self.gallery_dir = osp.join(self.data_dir, 'bounding_box_test')
        self.extra_gallery_dir = osp.join(self.data_dir, 'images')
        # self.market1501_500k = market1501_500k
        #
        # required_files = [
        #     self.data_dir, self.train_dir, self.query_dir, self.gallery_dir
        # ]
        # if self.market1501_500k:
        #     required_files.append(self.extra_gallery_dir)
        # self.check_before_run(required_files)

        train = self.process_dir(self.train_dir, relabel=True)
        query = self.process_dir(self.query_dir, relabel=False)
        gallery = self.process_dir(self.gallery_dir, relabel=False)
        if self.market1501_500k:
            gallery += self.process_dir(self.extra_gallery_dir, relabel=False)

        super(Market1501, self).__init__(train, query, gallery, **kwargs)

    def process_dir(self, dir_path, relabel=False):
        img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([-\d]+)_c(\d)')

        pid_container = set()
        for img_path in img_paths:
            pid, _ = map(int, pattern.search(img_path).groups())
            if pid == -1:
                continue  # junk images are just ignored
            pid_container.add(pid)
        pid2label = {pid: label for label, pid in enumerate(pid_container)}

        data = []
        for img_path in img_paths:
            pid, camid = map(int, pattern.search(img_path).groups())
            if pid == -1:
                continue  # junk images are just ignored
            assert 0 <= pid <= 1501  # pid == 0 means background
            assert 1 <= camid <= 6
            camid -= 1  # index starts from 0
            if relabel:
                pid = pid2label[pid]
            data.append((img_path, pid, camid, 'market1501', pid))

        return data
