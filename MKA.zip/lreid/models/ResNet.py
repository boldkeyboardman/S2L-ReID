'''
# encoding: utf-8
    """
    @author:  liaoxingyu
    @contact: sherlockliao01@gmail.com
    """

import logging
import math
import numpy as np

import torch
from torch import nn

from fastreid.layers import (
    IBN,
    SELayer,
    Non_local,
    get_norm,
)
from fastreid.utils.checkpoint import get_missing_parameters_message, get_unexpected_parameters_message
from .build import BACKBONE_REGISTRY
from fastreid.utils import comm


logger = logging.getLogger(__name__)
model_urls = {
    '18x': 'https://download.pytorch.org/models/resnet18-5c106cde.pth',
    '34x': 'https://download.pytorch.org/models/resnet34-333f7ec4.pth',
    '50x': 'https://download.pytorch.org/models/resnet50-19c8e357.pth',
    '101x': 'https://download.pytorch.org/models/resnet101-5d3b4d8f.pth',
    'ibn_18x': 'https://github.com/XingangPan/IBN-Net/releases/download/v1.0/resnet18_ibn_a-2f571257.pth',
    'ibn_34x': 'https://github.com/XingangPan/IBN-Net/releases/download/v1.0/resnet34_ibn_a-94bc1577.pth',
    'ibn_50x': 'https://github.com/XingangPan/IBN-Net/releases/download/v1.0/resnet50_ibn_a-d9d0bb7b.pth',
    'ibn_101x': 'https://github.com/XingangPan/IBN-Net/releases/download/v1.0/resnet101_ibn_a-59ea0ac6.pth',
    'se_ibn_101x': 'https://github.com/XingangPan/IBN-Net/releases/download/v1.0/se_resnet101_ibn_a-fabed4e2.pth',
}


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, bn_norm, with_ibn=False, with_se=False,
                 stride=1, downsample=None, reduction=16):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        if with_ibn:
            self.bn1 = IBN(planes, bn_norm)
        else:
            self.bn1 = get_norm(bn_norm, planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = get_norm(bn_norm, planes)
        self.relu = nn.ReLU(inplace=True)
        if with_se:
            self.se = SELayer(planes, reduction)
        else:
            self.se = nn.Identity()
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.se(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, bn_norm, with_ibn=False, with_se=False,
                 stride=1, downsample=None, reduction=16):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        if with_ibn:
            self.bn1 = IBN(planes, bn_norm)
        else:
            self.bn1 = get_norm(bn_norm, planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = get_norm(bn_norm, planes)
        self.conv3 = nn.Conv2d(planes, planes * self.expansion, kernel_size=1, bias=False)
        self.bn3 = get_norm(bn_norm, planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        if with_se:
            self.se = SELayer(planes * self.expansion, reduction)
        else:
            self.se = nn.Identity()
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)
        out = self.se(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class SNR(nn.Module):
    def __init__(self, inchannel):
        super(SNR, self).__init__()
        self.In = nn.InstanceNorm2d(inchannel)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.w1 = nn.Linear(inchannel, int(inchannel / 16))
        self.relu = nn.ReLU()
        self.w2 = nn.Linear(int(inchannel / 16), inchannel)

    def get_ak(self, R):
        x = self.pool(R)
        x = x.view(x.shape[0], -1)
        x = self.relu(self.w1(x))
        x = nn.Sigmoid()(self.w2(x))
        return x

    def compute_dist(self, x, y):
        m, n = x.size(0), y.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
        dist = (xx + yy).float()
        dist.addmm_(1, -2, x.float(), y.float().t())
        dist = dist.clamp(min=1e-12).sqrt()
        return dist

    def compute_loss(self, dista, distb, labels):
        loss = 0
        N = dista.size(0)
        is_pos = labels.expand(N, N).eq(labels.expand(N, N).t())
        is_neg = labels.expand(N, N).ne(labels.expand(N, N).t())
        dista_ap = dista[is_pos]
        dista_an = dista[is_neg]
        distb_ap = distb[is_pos]
        distb_an = distb[is_neg]
        loss = loss + nn.Softplus()(dista_ap - distb_ap).mean()

        loss = loss + nn.Softplus()(distb_an - dista_an).mean()
        return loss

    def forward(self, x, labels, flag=None):
        loss = 0
        if self.training:
            x_p, x_n, x_, F_x, F_n, ak = self.__forward(x)
            if flag != None:
                x_ = flag
            dist_p = self.compute_dist(x_p, x_p)
            dist_ = self.compute_dist(x_, x_)
            dist_n = self.compute_dist(x_n, x_n)
            loss = loss + self.compute_loss(dist_p, dist_, labels)
            loss = loss + self.compute_loss(dist_, dist_n, labels)
            return F_x, loss, F_n, x_p
        else:
            F_x = self.__forward(x)
            return F_x

    def __forward(self, f):
        f_ = self.In(f)
        R = f - f_
        ak = self.get_ak(R)
        ak = ak.view(ak.shape[0], ak.shape[1], 1, 1)
        R_p = ak * R
        F_p = R_p + f_
        f_p = self.pool(F_p)
        if self.training:

            R_n = (1 - ak) * R
            F_n = R_n + f_

            f_n = self.pool(F_n)
            f_ = self.pool(f_)
            return f_p.squeeze(), f_n.squeeze(), f_.squeeze(), F_p, F_n, ak
        else:
            return F_p

class ResNet(nn.Module):
    def __init__(self, last_stride, bn_norm, with_ibn, with_se, with_nl, block, layers, non_layers):
        self.inplanes = 64
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = get_norm(bn_norm, 64)
        self.relu = nn.ReLU(inplace=True)
        # self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True)
        self.layer1 = self._make_layer(block, 64, layers[0], 1, bn_norm, with_ibn, with_se)
        self.layer2 = self._make_layer(block, 128, layers[1], 2, bn_norm, with_ibn, with_se)
        self.layer3 = self._make_layer(block, 256, layers[2], 2, bn_norm, with_ibn, with_se)
        self.layer4 = self._make_layer(block, 512, layers[3], last_stride, bn_norm, with_se=with_se)

        self.snr1 = SNR(256)
        self.snr2 = SNR(512)
        self.snr3 = SNR(1024)
        self.snr4 = SNR(2048)
        self.random_init()
        self.marketfeatures = np.load('marketfeaturesv2.npy', allow_pickle= True).item()
        self.l1loss = nn.L1Loss()

        # fmt: off
        if with_nl: self._build_nonlocal(layers, non_layers, bn_norm)
        else:       self.NL_1_idx = self.NL_2_idx = self.NL_3_idx = self.NL_4_idx = []
        # fmt: on

    def _make_layer(self, block, planes, blocks, stride=1, bn_norm="BN", with_ibn=False, with_se=False):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                get_norm(bn_norm, planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, bn_norm, with_ibn, with_se, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, bn_norm, with_ibn, with_se))

        return nn.Sequential(*layers)

    def _build_nonlocal(self, layers, non_layers, bn_norm):
        self.NL_1 = nn.ModuleList(
            [Non_local(256, bn_norm) for _ in range(non_layers[0])])
        self.NL_1_idx = sorted([layers[0] - (i + 1) for i in range(non_layers[0])])
        self.NL_2 = nn.ModuleList(
            [Non_local(512, bn_norm) for _ in range(non_layers[1])])
        self.NL_2_idx = sorted([layers[1] - (i + 1) for i in range(non_layers[1])])
        self.NL_3 = nn.ModuleList(
            [Non_local(1024, bn_norm) for _ in range(non_layers[2])])
        self.NL_3_idx = sorted([layers[2] - (i + 1) for i in range(non_layers[2])])
        self.NL_4 = nn.ModuleList(
            [Non_local(2048, bn_norm) for _ in range(non_layers[3])])
        self.NL_4_idx = sorted([layers[3] - (i + 1) for i in range(non_layers[3])])

    def forward(self, x, targets, img_paths=None):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        conloss = None
        loss = 0
        f_nlist = []

        # layer 1
        NL1_counter = 0
        if len(self.NL_1_idx) == 0:
            self.NL_1_idx = [-1]
        for i in range(len(self.layer1)):
            x = self.layer1[i](x)
            if i == self.NL_1_idx[NL1_counter]:
                _, C, H, W = x.shape
                x = self.NL_1[NL1_counter](x)
                NL1_counter += 1
        if self.training:
            # if 'Market' in img_paths[0]:
            #     conloss = torch.zeros((64,256),device='cuda:0')
            #     for i, img_path in enumerate(img_paths):
            #         conloss[i] = self.marketfeatures['snr1'+img_path].to('cuda:0')
            x, snr_loss, F_n, ak = self.snr1(x, targets, conloss)
            loss += 0.1 * snr_loss
            f_nlist.append(F_n)
            # for i, img_path in enumerate(img_paths):
            #     self.marketfeatures['snr1'+img_path] = ak[i].cpu()
        else:
            x = self.snr1(x, targets)
        # layer 2
        NL2_counter = 0
        if len(self.NL_2_idx) == 0:
            self.NL_2_idx = [-1]
        for i in range(len(self.layer2)):
            x = self.layer2[i](x)
            if i == self.NL_2_idx[NL2_counter]:
                _, C, H, W = x.shape
                x = self.NL_2[NL2_counter](x)
                NL2_counter += 1
        if self.training:
            # if 'Market' in img_paths[0]:
            #     conloss = torch.zeros((64,512,),device='cuda:0')
            #     for i, img_path in enumerate(img_paths):
            #         conloss[i] = self.marketfeatures['snr2'+img_path].to('cuda:0')
            x, snr_loss, F_n, ak = self.snr2(x, targets, conloss)
            loss += 0.1 * snr_loss
            f_nlist.append(F_n)
            # for i, img_path in enumerate(img_paths):
            #     self.marketfeatures['snr2'+img_path] = ak[i].cpu()
        else:
            x = self.snr2(x, targets)
        # layer 3
        NL3_counter = 0
        if len(self.NL_3_idx) == 0:
            self.NL_3_idx = [-1]
        for i in range(len(self.layer3)):
            x = self.layer3[i](x)
            if i == self.NL_3_idx[NL3_counter]:
                _, C, H, W = x.shape
                x = self.NL_3[NL3_counter](x)
                NL3_counter += 1
        if self.training:
            # if 'Market' in img_paths[0]:
                # conloss = torch.zeros((64,1024,),device='cuda:0')
                # for i, img_path in enumerate(img_paths):
                #     conloss[i] = self.marketfeatures['snr3'+img_path].to('cuda:0')
            x, snr_loss, F_n, ak = self.snr3(x, targets, conloss)
            loss += 0.5 * snr_loss
            f_nlist.append(F_n)
            # for i, img_path in enumerate(img_paths):
            #     self.marketfeatures['snr3'+img_path] = ak[i].cpu()
        else:
            x = self.snr3(x, targets)

        # layer 4
        NL4_counter = 0
        if len(self.NL_4_idx) == 0:
            self.NL_4_idx = [-1]
        for i in range(len(self.layer4)):
            x = self.layer4[i](x)
            if i == self.NL_4_idx[NL4_counter]:
                _, C, H, W = x.shape
                x = self.NL_4[NL4_counter](x)
                NL4_counter += 1
        if self.training:
            # if 'Market' in img_paths[0]:
            #     conloss = torch.zeros((64,2048,),device='cuda:0')
            #     for i, img_path in enumerate(img_paths):
            #         conloss[i] = self.marketfeatures['snr4'+img_path].to('cuda:0')
            x, snr_loss, F_n, ak = self.snr4(x, targets, conloss)
            loss += 0.5 * snr_loss
            f_nlist.append(F_n)
            #for i, img_path in enumerate(img_paths):
             #   self.marketfeatures['snr4'+img_path] = ak[i].cpu()
            #f 'Market' in img_paths[0]:
             #   conloss = torch.zeros((64,2048),device='cuda:0')
              #  for i, img_path in enumerate(img_paths):
               #     conloss[i] = self.l1loss(self.marketfeatures['snr4'+img_path].to('cuda:0'), x[i])
                #closs4 = torch.sum(conloss)/64.
                #conloss = (closs1 + closs2 + closs3*3 + closs4*6) #* 2.
        else:
            x = self.snr4(x, targets)
        return x, loss, f_nlist

    def random_init(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                nn.init.normal_(m.weight, 0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


def init_pretrained_weights(key):
    """Initializes model with pretrained weights.

    Layers that don't match with pretrained layers in name or size are kept unchanged.
    """
    import os
    import errno
    import gdown

    def _get_torch_home():
        ENV_TORCH_HOME = 'TORCH_HOME'
        ENV_XDG_CACHE_HOME = 'XDG_CACHE_HOME'
        DEFAULT_CACHE_DIR = '~/.cache'
        torch_home = os.path.expanduser(
            os.getenv(
                ENV_TORCH_HOME,
                os.path.join(
                    os.getenv(ENV_XDG_CACHE_HOME, DEFAULT_CACHE_DIR), 'torch'
                )
            )
        )
        return torch_home

    torch_home = _get_torch_home()
    model_dir = os.path.join(torch_home, 'checkpoints')
    try:
        os.makedirs(model_dir)
    except OSError as e:
        if e.errno == errno.EEXIST:
            # Directory already exists, ignore.
            pass
        else:
            # Unexpected OSError, re-raise.
            raise

    filename = model_urls[key].split('/')[-1]

    cached_file = os.path.join(model_dir, filename)

    if not os.path.exists(cached_file):
        logger.info(f"Pretrain model don't exist, downloading from {model_urls[key]}")
        if comm.is_main_process():
            gdown.download(model_urls[key], cached_file, quiet=False)

    comm.synchronize()

    logger.info(f"Loading pretrained model from {cached_file}")
    state_dict = torch.load(cached_file, map_location=torch.device('cpu'))

    return state_dict


@BACKBONE_REGISTRY.register()
def build_resnet_backbone(cfg):
    """
    Create a ResNet instance from config.
    Returns:
        ResNet: a :class:`ResNet` instance.
    """

    # fmt: off
    pretrain      = cfg.MODEL.BACKBONE.PRETRAIN
    pretrain_path = cfg.MODEL.BACKBONE.PRETRAIN_PATH
    last_stride   = cfg.MODEL.BACKBONE.LAST_STRIDE
    bn_norm       = cfg.MODEL.BACKBONE.NORM
    with_ibn      = cfg.MODEL.BACKBONE.WITH_IBN
    with_se       = cfg.MODEL.BACKBONE.WITH_SE
    with_nl       = cfg.MODEL.BACKBONE.WITH_NL
    depth         = cfg.MODEL.BACKBONE.DEPTH
    # fmt: on

    num_blocks_per_stage = {
        '18x': [2, 2, 2, 2],
        '34x': [3, 4, 6, 3],
        '50x': [3, 4, 6, 3],
        '101x': [3, 4, 23, 3],
    }[depth]

    nl_layers_per_stage = {
        '18x': [0, 0, 0, 0],
        '34x': [0, 0, 0, 0],
        '50x': [0, 2, 3, 0],
        '101x': [0, 2, 9, 0]
    }[depth]

    block = {
        '18x': BasicBlock,
        '34x': BasicBlock,
        '50x': Bottleneck,
        '101x': Bottleneck
    }[depth]

    model = ResNet(last_stride, bn_norm, with_ibn, with_se, with_nl, block,
                   num_blocks_per_stage, nl_layers_per_stage)
    if pretrain:
        # Load pretrain path if specifically
        if pretrain_path:
            try:
                state_dict = torch.load(pretrain_path, map_location=torch.device('cpu'))
                logger.info(f"Loading pretrained model from {pretrain_path}")
            except FileNotFoundError as e:
                logger.info(f'{pretrain_path} is not found! Please check this path.')
                raise e
            except KeyError as e:
                logger.info("State dict keys error! Please check the state dict.")
                raise e
        else:
            key = depth
            if with_ibn: key = 'ibn_' + key
            if with_se:  key = 'se_' + key

            state_dict = init_pretrained_weights(key)

        incompatible = model.load_state_dict(state_dict, strict=False)
        if incompatible.missing_keys:
            logger.info(
                get_missing_parameters_message(incompatible.missing_keys)
            )
        if incompatible.unexpected_keys:
            logger.info(
                get_unexpected_parameters_message(incompatible.unexpected_keys)
            )

    return model
'''

# encoding: utf-8
"""
@author:  liaoxingyu
@contact: sherlockliao01@gmail.com
"""

import math
import copy
import os
# import gdown
import errno
import logging
import numpy as np

import torch
from torch import nn
from .bnneck import BNClassifier

from lreid.layers import (
    IBN,
    SELayer,
    Non_local,
    get_norm,
    RGA_Module,
)
logger = logging.getLogger(__name__)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, bn_norm, with_ibn=True, with_se=False,
                 stride=1, downsample=None, reduction=16):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        if with_ibn:
            self.bn1 = IBN(planes, bn_norm)
        else:
            self.bn1 = get_norm(bn_norm, planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = get_norm(bn_norm, planes)
        self.relu = nn.ReLU(inplace=True)
        if with_se:
            self.se = SELayer(planes, reduction)
        else:
            self.se = nn.Identity()
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.se(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, bn_norm, with_ibn=True, with_se=False,
                 stride=1, downsample=None, reduction=16):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        if with_ibn:
            self.bn1 = IBN(planes, bn_norm)
        else:
            self.bn1 = get_norm(bn_norm, planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = get_norm(bn_norm, planes)
        self.conv3 = nn.Conv2d(planes, planes * self.expansion, kernel_size=1, bias=False)
        self.bn3 = get_norm(bn_norm, planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        if with_se:
            self.se = SELayer(planes * self.expansion, reduction)
        else:
            self.se = nn.Identity()
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)
        out = self.se(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class GlobalPoolFlat(nn.Module):
    def __init__(self, pool_mode='avg'):
        super(GlobalPoolFlat, self).__init__()
        if pool_mode == 'avg':
            self.pool = nn.AdaptiveAvgPool2d(1)
        else:
            self.pool = nn.AdaptiveMaxPool2d(1)

    def forward(self, x):
        x = self.pool(x)
        if len(x.size()) == 4:
            n, c = x.size(0), x.size(1)
        else:
            assert len(x.size()) == 4
        flatted = x.view(n, -1)
        assert flatted.size(1) == c
        return flatted


class ResNet(nn.Module):
    def __init__(self, class_num_list, pretrained=True, last_stride=1, bn_norm="BN", with_ibn=True, with_se=False, \
                 with_nl=False, block=Bottleneck, layers=[3, 4, 6, 3], non_layers=[0, 2, 3, 0]):
        self.inplanes = 64
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = get_norm(bn_norm, 64)
        self.relu = nn.ReLU(inplace=True)
        # self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True)
        self.layer1 = self._make_layer(block, 64, layers[0], 1, bn_norm, with_ibn, with_se)
        self.layer2 = self._make_layer(block, 128, layers[1], 2, bn_norm, with_ibn, with_se)
        self.layer3 = self._make_layer(block, 256, layers[2], 2, bn_norm, with_ibn, with_se)
        self.layer4 = self._make_layer(block, 512, layers[3], last_stride, bn_norm, with_se=with_se)

        self.random_init()

        # RGA Modules
        self.rga_att1 = RGA_Module(256, 64*32, use_spatial=True, use_channel=True,
                                   cha_ratio=8, spa_ratio=8, down_ratio=8)
        self.rga_att2 = RGA_Module(512, 32*16, use_spatial=True, use_channel=True,
                                   cha_ratio=8, spa_ratio=8, down_ratio=8)
        self.rga_att3 = RGA_Module(1024, 16*8, use_spatial=True, use_channel=True,
                                   cha_ratio=8, spa_ratio=8, down_ratio=8)
        self.rga_att4 = RGA_Module(2048, 16*8, use_spatial=True, use_channel=True,
                                   cha_ratio=8, spa_ratio=8, down_ratio=8)

        # Lwf
        self.class_num_list = class_num_list
        self.feature_dim = 2048
        self.encoder_feature = nn.Sequential(GlobalPoolFlat(pool_mode='avg'),)
        self.classifier_dict = nn.ModuleDict()
        self.all_num = 0
        # for step, num in enumerate(self.class_num_list[:-1]):
        #     self.all_num += num
        self.classifier_dict[f'step:{0}'] = BNClassifier(self.feature_dim, 2000) # self.all_num
        # fmt: off
        if with_nl: self._build_nonlocal(layers, non_layers, bn_norm)
        else:       self.NL_1_idx = self.NL_2_idx = self.NL_3_idx = self.NL_4_idx = []
        if pretrained:
            # Load pretrain path if specifically
            def _get_torch_home():
                ENV_TORCH_HOME = 'TORCH_HOME'
                ENV_XDG_CACHE_HOME = 'XDG_CACHE_HOME'
                DEFAULT_CACHE_DIR = '~/.cache'
                torch_home = os.path.expanduser(
                    os.getenv(
                        ENV_TORCH_HOME,
                        os.path.join(
                            os.getenv(ENV_XDG_CACHE_HOME, DEFAULT_CACHE_DIR), 'torch'
                        )
                    )
                )
                return torch_home

            torch_home = _get_torch_home()
            model_dir = os.path.join(torch_home, 'checkpoints')
            try:
                os.makedirs(model_dir)
            except OSError as e:
                if e.errno == errno.EEXIST:
                    # Directory already exists, ignore.
                    pass
                else:
                    # Unexpected OSError, re-raise.
                    raise
            pretrain_path = os.path.join(model_dir, 'resnet50-19c8e357.pth')
            #print('********************',pretrain_path,'**************************')
            # if not os.path.exists(pretrain_path):
            #     gdown.download('https://download.pytorch.org/models/resnet50-19c8e357.pth', pretrain_path, quiet=False)
            #pretrain_path = '/home/jy/.cache/torch/hub/checkpoints/resnet50-19c8e357.pth'
            try:
                state_dict = torch.load(pretrain_path, map_location=torch.device('cpu'))
                logger.info(f"Loading pretrained model from {pretrain_path}")
            except FileNotFoundError as e:
                logger.info(f'{pretrain_path} is not found! Please check this path.')
                raise e
            except KeyError as e:
                logger.info("State dict keys error! Please check the state dict.")
                raise e

            self.load_state_dict(state_dict, strict=False)
        # fmt: on

    def _make_layer(self, block, planes, blocks, stride=1, bn_norm="BN", with_ibn=False, with_se=False):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                get_norm(bn_norm, planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, bn_norm, with_ibn, with_se, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, bn_norm, with_ibn, with_se))

        return nn.Sequential(*layers)

    def _build_nonlocal(self, layers, non_layers, bn_norm):
        self.NL_1 = nn.ModuleList(
            [Non_local(256, bn_norm) for _ in range(non_layers[0])])
        self.NL_1_idx = sorted([layers[0] - (i + 1) for i in range(non_layers[0])])
        self.NL_2 = nn.ModuleList(
            [Non_local(512, bn_norm) for _ in range(non_layers[1])])
        self.NL_2_idx = sorted([layers[1] - (i + 1) for i in range(non_layers[1])])
        self.NL_3 = nn.ModuleList(
            [Non_local(1024, bn_norm) for _ in range(non_layers[2])])
        self.NL_3_idx = sorted([layers[2] - (i + 1) for i in range(non_layers[2])])
        self.NL_4 = nn.ModuleList(
            [Non_local(2048, bn_norm) for _ in range(non_layers[3])])
        self.NL_4_idx = sorted([layers[3] - (i + 1) for i in range(non_layers[3])])

    def forward(self, x, current_step=0, flag=True):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        # layer 1
        NL1_counter = 0
        if len(self.NL_1_idx) == 0:
            self.NL_1_idx = [-1]
        for i in range(len(self.layer1)):
            x = self.layer1[i](x)
            if i == self.NL_1_idx[NL1_counter]:
                _, C, H, W = x.shape
                x = self.NL_1[NL1_counter](x)
                NL1_counter += 1
        x = self.rga_att1(x)
        # layer 2
        NL2_counter = 0
        if len(self.NL_2_idx) == 0:
            self.NL_2_idx = [-1]
        for i in range(len(self.layer2)):
            x = self.layer2[i](x)
            if i == self.NL_2_idx[NL2_counter]:
                _, C, H, W = x.shape
                x = self.NL_2[NL2_counter](x)
                NL2_counter += 1
        x = self.rga_att2(x)
        # layer 3
        NL3_counter = 0
        if len(self.NL_3_idx) == 0:
            self.NL_3_idx = [-1]
        for i in range(len(self.layer3)):
            x = self.layer3[i](x)
            if i == self.NL_3_idx[NL3_counter]:
                _, C, H, W = x.shape
                x = self.NL_3[NL3_counter](x)
                NL3_counter += 1
        x = self.rga_att3(x)
        # f3 = x
        # layer 4
        NL4_counter = 0
        if len(self.NL_4_idx) == 0:
            self.NL_4_idx = [-1]
        for i in range(len(self.layer4)):
            x = self.layer4[i](x)
            if i == self.NL_4_idx[NL4_counter]:
                _, C, H, W = x.shape
                x = self.NL_4[NL4_counter](x)
                NL4_counter += 1
        x = self.rga_att4(x)
        # Lwf
        feature_maps = x
        features = self.encoder_feature(feature_maps)
        bned_features, cls_score = self.classifier_dict[f'step:{0}'](features)
        if self.training and flag:
            return  features, cls_score, feature_maps
        else:
            return  bned_features, feature_maps  # for vis_lifelong cls_score


    def random_init(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                nn.init.normal_(m.weight, 0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def classify_latent_codes(self, latent_codes, current_step):
        if isinstance(current_step, list):
            cls_score_list = []
            for c_s in current_step:
                bned_features, cls_score = self.classifier_dict[f'step:{c_s}'](latent_codes)
                cls_score_list.append(cls_score)
            if self.training:
                # cls_score = torch.cat(cls_score_list, dim=1)
                return None, cls_score_list, None
            else:
                return bned_features, None
        else:
            bned_features, cls_score = self.classifier_dict[f'step:{current_step}'](latent_codes)
            if self.training:
                return None, cls_score, None
            else:
                return bned_features, None