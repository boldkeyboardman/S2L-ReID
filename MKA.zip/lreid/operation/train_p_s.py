import torch
from lreid.tools import MultiItemAverageMeter
from lreid.evaluation import accuracy
import os.path as osp

def train_p_s_an_epoch(config, base, loader, current_step, old_model=False, current_epoch=None, ema=None, output_featuremaps=True):
    base.set_all_model_train()
    meter = MultiItemAverageMeter()
    if old_model:
        print('****** training both tasknet and old_model ******\n')
    else:
        print('****** training with tasknet ******\n')

    ### we assume 200 iterations as an epoch
    for _ in range(config.steps): # config.steps
        base.set_model_and_optimizer_zero_grad()
        ### load a batch data
        mini_batch = loader.continual_train_iter_dict[
            current_step].next_one()
        if mini_batch[0].size(0) != config.p * config.k:
            mini_batch = loader.continual_train_iter_dict[
                current_step].next_one()
        imgs, global_pids, global_cids, dataset_name, local_pids, image_paths = mini_batch

        if len(mini_batch) > 6:
            assert config.continual_step == 'task'
        imgs, local_pids, global_pids = imgs.to(base.device), local_pids.to(base.device), global_pids.to(base.device)
        # if we use low precision, input also need to be fp16
        if config.fp_16:
           imgs = imgs.half()
        ### forward
        features, cls_score, feature_maps = base.model_dict['tasknet'](imgs, current_step)
        ### loss
        ide_loss = config.weight_x * base.ide_criterion(cls_score, global_pids)
        loss = ide_loss
        acc = accuracy(cls_score, global_pids, [1])[0]
        ### optimize
        base.optimizer_dict['tasknet'].zero_grad()
        if config.fp_16:  # we use optimier to backward loss
            with base.amp.scale_loss(loss, base.optimizer_list) as scaled_loss:
                scaled_loss.backward()
        else:
            loss.backward()
        base.optimizer_dict['tasknet'].step()

        if old_model:
            mini_batch = loader.continual_train_iter_dict[
                int(config.continual_step)].next_one()
            if mini_batch[0].size(0) != config.p * config.k:
                mini_batch = loader.continual_train_iter_dict[
                    int(config.continual_step)].next_one()
            imgs, global_pids, global_cids, dataset_name, local_pids, image_paths = mini_batch

            if len(mini_batch) > 6:
                assert config.continual_step == 'task'
            imgs, local_pids, global_pids = imgs.to(base.device), local_pids.to(base.device), global_pids.to(base.device)
            # if we use low precision, input also need to be fp16
            if config.fp_16:
                imgs = imgs.half()
            features, cls_score, feature_maps = base.model_dict['tasknet'](imgs, current_step)
            with torch.no_grad():
                old_features, old_cls_score, old_feature_maps = base.model_dict['old_model'](imgs, current_step)
            # store_loss = base.reconstruction_criterion(old_feature_maps, feature_maps)
            del old_features, old_feature_maps, features, feature_maps  # mask, old_mask,
            torch.cuda.empty_cache()

            knowladge_distilation_loss = config.weight_kd * base.loss_fn_kd(cls_score, old_cls_score, config.kd_T) #+ store_loss
            # knowladge_distilation_loss = store_loss
            meter.update({
                'Kd_loss': knowladge_distilation_loss.data,
            })
            loss = knowladge_distilation_loss

            ### optimize
            base.optimizer_dict['tasknet'].zero_grad()
            if config.fp_16:  # we use optimier to backward loss
                with base.amp.scale_loss(loss, base.optimizer_list) as scaled_loss:
                    scaled_loss.backward()
            else:
                loss.backward()

            base.optimizer_dict['tasknet'].step()
            if ema:
                base.update()

        ### recored
        meter.update({'ide_loss': ide_loss.data,
                      'acc': acc,
                      })
    if config.re_init_lr_scheduler_per_step:
        _lr_scheduler_step = current_epoch
    else:
        _lr_scheduler_step = current_step * config.total_train_epochs + current_epoch
    base.lr_scheduler_dict['tasknet'].step(_lr_scheduler_step)
    return (meter.get_value_dict(), meter.get_str())

